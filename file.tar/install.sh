#!/bin/sh
##--Author Manivannan, www.Assistanz.com--##
echo "**************************Install and update FFmpeg via CLI on Linux Server*****************************"
if [ "`/usr/bin/whoami`" != "root" ]; then
    echo -e "\e[101mYou need to execute this script as root on the server!\e[0m"
    exit 1
fi
   ffmpeg -version  > /dev/null 2>&1
   old=$(ffmpeg -version| grep "ffmpeg version" | awk {'print $3'} | cut -d'-' -f1)
   if [ -z "$old" ]
   then
   echo  -e "\e[41mCurrently the ffmpeg is not installed on the server!!!\e[0m"
   echo -n  -e "\e[96mIf would you like to install ffmpeg software on the server!!!?\e[0m[yes or no]:"
   read yno
   case $yno in
       [yY] | [yY][Ee][Ss] )
                        echo -e "\e[1;31mInstalltion will be start!!!\e[0m"
			read -p "Press [Enter] key to continue..." readEnterKey
                        cd /usr/local/bin
			mkdir ffmpeg && chown root.root ffmpeg
			cd ffmpeg
			yum -y install wget
			yum -y install unzip
			wget https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-amd64-static.tar.xz
			wget --no-check-certificate  https://github.com/vot/ffbinaries-prebuilt/releases/download/v3.4/ffserver-3.4-linux-64.zip
			tar xf ffmpeg-release-amd64-static.tar.xz
			unzip ffserver-3.4-linux-64.zip
			cd ffmpeg*
			./ffmpeg -version
			chown root.root -R *
			mv * ../
			ln -s /usr/local/bin/ffmpeg/ffmpeg /usr/bin/ffmpeg
			ln -s /usr/local/bin/ffmpeg/ffprobe /usr/bin/ffprobe #for ffprobe
			ln -s /usr/local/bin/ffmpeg/qt-faststart	/usr/bin/qt-faststart #for qt-faststart
			ln -s /usr/local/bin/ffmpeg/ffserver /usr/bin/ffserver	#for ffserver
			echo -e "\e[103mThe ffmpeg installtion complete and path is below!!!\e[0m"
			which ffmpeg
			whereis ffmpeg
			echo -e "\e[103mYou are now able to run the ffmpeg command from anywhere!!!\e[0m"		
                	;;

        [nN] | [n|N][O|o] )
                        echo -e "\e[33mYou have press NO option and installtion is cancelled!!!\e[0m"
                        echo -e "\e[31mPress Yes to contine the ffmpeg software installtion on the server!!!\e[0m"
                        echo -e "\e[1;32mBye!!!\e[0m"
                        exit 1
                        ;;
        *) echo "Invalid input"
            ;;
esac
else
   new=$(curl -k -s "https://johnvansickle.com/ffmpeg/release-readme.txt" | grep "version:" | awk -F':' {'print $2'} | xargs -n1)
   printf "%s\n" "$old" "$new" | sort -V -r   
   if [ $(printf "%s\n" "$old" "$new" | sort -V -r | head -1) = "$old" ] ; then
   if [ "$old" != "$new" ] ; then
   echo "$old you are using the newer version of ffmpeg $new"
   else
   echo "$old Both versions are equal $new"
   fi 
   else
   echo "$old is older than $new"
   echo -e "\e[1;31mIf you wish to update the ffmpeg software on the server!!!\e[0m"   
while   :
do
#echo "If would you like to install ffmpeg software on the server?"
   read -p "Enter your choice [ 1 - 2 ] " choice
   case $choice in
                1)
                       echo -e "\e[1;31mInstalltion will be start!!!\e[0m"
		       read -p "Press [Enter] key to continue..." readEnterKey
                        unlink /usr/bin/ffmpeg
			unlink /usr/bin/ffprobe
                        unlink /usr/bin/qt-faststart 
			unlink /usr/bin/ffserver	
			mv /usr/include/ffmpeg	/usr/include/ffmpeg-mv 
			mv /usr/share/ffmpeg	/usr/share/ffmpeg-mv 
			mv /usr/share/man/man1/ffmpeg.1.gz	/usr/share/man/man1/ffmpeg.1.gz-mv
			cd /usr/local/bin
			mkdir ffmpeg && chown root.root ffmpeg
			cd ffmpeg
			yum -y install wget
			yum -y install unzip
			wget https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-amd64-static.tar.xz
			wget --no-check-certificate  https://github.com/vot/ffbinaries-prebuilt/releases/download/v3.4/ffserver-3.4-linux-64.zip
			tar xf ffmpeg-release-amd64-static.tar.xz
			unzip ffserver-3.4-linux-64.zip
			cd ffmpeg*
			./ffmpeg -version
			chown root.root -R *
			mv * ../
			ln -s /usr/local/bin/ffmpeg/ffmpeg /usr/bin/ffmpeg
			ln -s /usr/local/bin/ffmpeg/ffprobe /usr/bin/ffprobe #for ffprobe
			ln -s /usr/local/bin/ffmpeg/qt-faststart	/usr/bin/qt-faststart #for qt-faststart
			ln -s /usr/local/bin/ffmpeg/ffserver  /usr/bin/ffserver #for ffserver
			echo -e "\e[103mThe ffmpeg updated process has been completed and path is below!\e[0m"
			which ffmpeg
			whereis ffmpeg
			echo -e "\e[103mYou are now able to run the ffmpeg command from anywhere!!!\e[0m" 
			exit 0		        
		        ;;
		 2)	
                        echo -e "\e[96mYou have selected choice 2 and can't able to update the ffmpeg software on the server!!!\e[0m"
                        echo -e "\e[35mPress 1 to contine the ffmpeg software installtion on the server!!!\e[0m"
                        echo -e "\e[1;31mBye!!!\e[0m"
                        exit 0
                        ;;
esac
done
fi
fi
